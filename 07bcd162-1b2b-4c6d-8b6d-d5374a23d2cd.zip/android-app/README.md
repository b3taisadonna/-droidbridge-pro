# DroidBridge Pro — Android Pro APK Projekt

Paket-ID: `de.droidbridge.pro.adb`
Version: `2.4.0-pro` (Code 240)
Bridge-Engine: `shizuku`
Target SDK: Android 35 (Min SDK 29)

## Enthaltene Pro-Module
- Prozess- & Dienstkontrolle: Aktiviert
- Speicher- & ART-Optimierer: Aktiviert
- Performance- & Governor-Tuner: Aktiviert
- Automatischer Backup-Planer: Aktiviert
- Intelligentes Ressourcenmanagement: Aktiviert

## APK lokal bauen
1. Öffne diesen Projektordner in **Android Studio Ladybug** oder neuer.
2. Führe im Terminal `./gradlew assembleRelease` aus.
3. Installiere die erzeugte APK direkt via ADB:
   `adb install -r app/build/outputs/apk/release/app-release.apk`

## Sofortige Wartung ohne APK-Build
Führe das beigefügte Skript `droidbridge-maintenance.sh` direkt am PC mit angeschlossenem Android-Gerät aus:
`chmod +x droidbridge-maintenance.sh && ./droidbridge-maintenance.sh`
