#!/usr/bin/env bash
# DroidBridge Pro (2.4.0-pro) — Automatisiertes ADB-Wartungsskript
set -euo pipefail

echo "Prüfe verbundene ADB-Geräte..."
adb wait-for-device
adb devices -l

echo "[1/4] Animationsskalen & Doze-Optimierung anwenden..."
adb shell settings put global window_animation_scale 0.5
adb shell settings put global transition_animation_scale 0.5
adb shell settings put global animator_duration_scale 0.5
adb shell settings put global cached_apps_freezer enabled

echo "[2/4] Speicheroptimierung & ART-Profilkompilierung..."
adb shell pm trim-caches 16G
adb shell sm fstrim
adb shell cmd package bg-dexopt-job || true

echo "[3/4] Hintergrundprozesse & Standby-Buckets durchsetzen..."
adb shell am force-stop de.telekom.android.customercenter
adb shell am set-standby-bucket de.telekom.android.customercenter rare
adb shell am force-stop com.facebook.services
adb shell am set-standby-bucket com.facebook.services restricted

echo "[4/4] Aktive Ressourcen-Regeln (3) synchronisieren..."
# Nacht-Doze & Wakelock-Sperre
adb shell dumpsys deviceidle force-idle && adb shell am set-standby-bucket com.instagram.android restricted
# Akku-Notfalldrosselung
adb shell settings put global low_power 1 && adb shell settings put global cached_apps_freezer enabled
# Speicher-Schwellenwert-Trim
adb shell pm trim-caches 4G && adb shell am send-trim-memory --user 0 com.android.chrome RUNNING_MODERATE

echo "Wartung erfolgreich abgeschlossen."
