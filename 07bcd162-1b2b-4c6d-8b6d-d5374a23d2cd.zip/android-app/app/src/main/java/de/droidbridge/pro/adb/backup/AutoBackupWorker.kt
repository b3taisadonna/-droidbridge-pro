package de.droidbridge.pro.adb.backup

import android.content.Context
import androidx.work.*
import de.droidbridge.pro.adb.bridge.AdbMaintenanceEngine
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class AutoBackupWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val engine = AdbMaintenanceEngine(applicationContext)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmm", Locale.GERMANY).format(Date())
        val targetDir = "/sdcard/DroidBridge/Backups/$stamp"
        engine.executeShell("mkdir -p $targetDir")
        engine.executeShell("settings list system > $targetDir/settings_system.txt")
        engine.executeShell("settings list global > $targetDir/settings_global.txt")
        engine.executeShell("pm list packages -3 > $targetDir/installed_user_packages.txt")
        return Result.success()
    }

    companion object {
        fun scheduleDailyBackup(context: Context) {
            val request = PeriodicWorkRequestBuilder<AutoBackupWorker>(24, TimeUnit.HOURS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiresBatteryNotLow(true)
                        .build()
                )
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "droidbridge_daily_backup",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
