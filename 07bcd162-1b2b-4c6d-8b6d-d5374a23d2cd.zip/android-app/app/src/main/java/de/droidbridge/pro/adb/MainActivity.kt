package de.droidbridge.pro.adb

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import de.droidbridge.pro.adb.backup.AutoBackupWorker
import de.droidbridge.pro.adb.bridge.AdbMaintenanceEngine
import de.droidbridge.pro.adb.storage.CleanupCandidate
import de.droidbridge.pro.adb.storage.StorageOptimizerWorker
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val engine = AdbMaintenanceEngine(applicationContext)
        AutoBackupWorker.scheduleDailyBackup(applicationContext)
        StorageOptimizerWorker.scheduleBackgroundCleanup(applicationContext, 24L, true, true, true)

        setContent {
            MaterialTheme {
                val scope = rememberCoroutineScope()
                var statusText by remember { mutableStateOf("Bereit für Systemwartung (Intervall: alle 24 Std.)") }
                var showPreviewDialog by remember { mutableStateOf(false) }
                val previewItems = remember {
                    mutableStateListOf(
                        CleanupCandidate("c1", "App-Caches", "/data/user/0/*/cache", 1420, "pm trim-caches 16G"),
                        CleanupCandidate("c2", "ART/ODEX-Reste", "/data/dalvik-cache", 620, "cmd package bg-dexopt-job"),
                        CleanupCandidate("c3", "Temp-Logs", "/data/local/tmp/*", 180, "rm -rf /data/local/tmp/*")
                    )
                }

                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(modifier = Modifier.padding(24.dp)) {
                        Text(
                            text = "DroidBridge Pro",
                            style = MaterialTheme.typography.headlineMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = statusText)
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = {
                                scope.launch {
                                    val res = engine.applyPerformanceProfile()
                                    statusText = "Profil angewendet (${res.size} ADB-Befehle ausgeführt)"
                                }
                            }) {
                                Text("Systemoptimierung")
                            }
                            OutlinedButton(onClick = { showPreviewDialog = true }) {
                                Text("Bereinigungsvorschau")
                            }
                        }
                    }

                    if (showPreviewDialog) {
                        AlertDialog(
                            onDismissRequest = { showPreviewDialog = false },
                            title = { Text("Vorschau der zu löschenden Elemente") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    previewItems.forEach { item ->
                                        Text("${item.label} (${item.estimatedMb} MB) — ${item.path}")
                                    }
                                }
                            },
                            confirmButton = {
                                Button(onClick = {
                                    showPreviewDialog = false
                                    scope.launch {
                                        previewItems.forEach { engine.executeShell(it.command) }
                                        statusText = "Vorschau-Bereinigung abgeschlossen"
                                    }
                                }) {
                                    Text("Jetzt bereinigen")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showPreviewDialog = false }) {
                                    Text("Abbrechen")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
