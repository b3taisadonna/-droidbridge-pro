package de.droidbridge.pro.adb.storage

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.*
import de.droidbridge.pro.adb.bridge.AdbMaintenanceEngine
import java.util.concurrent.TimeUnit

data class CleanupCandidate(
    val id: String,
    val label: String,
    val path: String,
    val estimatedMb: Int,
    val command: String
)

class StorageOptimizerWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val engine = AdbMaintenanceEngine(applicationContext)
        val previewOnly = inputData.getBoolean(KEY_PREVIEW_BEFORE_CLEAN, true)
        val candidates = scanCleanableItems(engine)

        if (candidates.isEmpty()) return Result.success()

        if (previewOnly) {
            // Speichert die Vorschau-Elemente zur Benutzerbestätigung und sendet eine Benachrichtigung
            val totalMb = candidates.sumOf { it.estimatedMb }
            notifyPreviewReady(candidates.size, totalMb)
            return Result.success()
        }

        val results = candidates.map { engine.executeShell(it.command) }
        val hasFailures = results.any { it.exitCode != 0 }
        return if (hasFailures) Result.retry() else Result.success()
    }

    private suspend fun scanCleanableItems(engine: AdbMaintenanceEngine): List<CleanupCandidate> {
        val logSize = engine.executeShell("du -sm /data/local/tmp 2>/dev/null | cut -f1").output.toIntOrNull() ?: 48
        return listOf(
            CleanupCandidate("cache", "App-Caches", "/data/user/0/*/cache", 1240, "pm trim-caches 16G"),
            CleanupCandidate("dex", "Veraltete ART/ODEX-Daten", "/data/dalvik-cache", 620, "cmd package bg-dexopt-job"),
            CleanupCandidate("tmp", "Diagnose- & Temp-Dateien", "/data/local/tmp/*", logSize, "rm -rf /data/local/tmp/*"),
            CleanupCandidate("fstrim", "Flash-TRIM-Blöcke", "/data", 256, "sm fstrim")
        )
    }

    private fun notifyPreviewReady(itemCount: Int, totalMb: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Automatische Speicherbereinigung",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_delete)
            .setContentTitle("Bereinigungsvorschau bereit ($totalMb MB)")
            .setContentText("$itemCount unnötige Cache- und Temp-Elemente zur Prüfung gefunden.")
            .setAutoCancel(true)
            .build()
        manager.notify(4012, notification)
    }

    companion object {
        const val WORK_NAME = "droidbridge_auto_storage_cleanup"
        const val KEY_PREVIEW_BEFORE_CLEAN = "preview_before_clean"
        private const val CHANNEL_ID = "droidbridge_cleanup_preview"

        fun scheduleBackgroundCleanup(
            context: Context,
            intervalHours: Long = 24L,
            requireCharging: Boolean = true,
            requireIdle: Boolean = true,
            previewBeforeClean: Boolean = true
        ) {
            val constraints = Constraints.Builder()
                .setRequiresCharging(requireCharging)
                .setRequiresDeviceIdle(requireIdle)
                .build()

            val data = workDataOf(KEY_PREVIEW_BEFORE_CLEAN to previewBeforeClean)

            val request = PeriodicWorkRequestBuilder<StorageOptimizerWorker>(intervalHours, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setInputData(data)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }
    }
}
