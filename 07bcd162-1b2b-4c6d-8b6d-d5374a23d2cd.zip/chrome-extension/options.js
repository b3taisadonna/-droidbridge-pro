chrome.storage.local.get(['wirelessConfig', 'cleanupIntervalHours']).then((data) => {
  if (data.wirelessConfig) {
    document.getElementById('opt-ip').value = data.wirelessConfig.ipAddress || '';
    document.getElementById('opt-port').value = data.wirelessConfig.port || 5555;
  }
  if (data.cleanupIntervalHours) {
    document.getElementById('opt-interval').value = String(data.cleanupIntervalHours);
  }
});

document.getElementById('opt-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const ipAddress = document.getElementById('opt-ip').value.trim();
  const port = Number(document.getElementById('opt-port').value) || 5555;
  const cleanupIntervalHours = Number(document.getElementById('opt-interval').value) || 24;
  await chrome.storage.local.set({
    wirelessConfig: { ipAddress, port },
    cleanupIntervalHours
  });
  chrome.alarms.create('droidbridge_auto_cleanup_reminder', {
    periodInMinutes: cleanupIntervalHours * 60
  });
  document.getElementById('saved').textContent = 'Einstellungen gespeichert.';
});
