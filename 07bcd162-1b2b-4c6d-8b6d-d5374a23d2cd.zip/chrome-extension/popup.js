const ADB_FILTER = { classCode: 0xff, subclassCode: 0x42, protocolCode: 0x01 };
let connectedLabel = 'Geräteprofil aktiv';

document.querySelectorAll('.tab').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((t) => t.classList.remove('active'));
    document.querySelectorAll('.panel').forEach((p) => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('panel-' + btn.dataset.tab).classList.add('active');
  });
});

document.getElementById('btn-options').addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
});

document.getElementById('btn-usb').addEventListener('click', async () => {
  const statusEl = document.getElementById('device-status');
  const outEl = document.getElementById('cmd-output');
  if (!navigator.usb) {
    outEl.textContent = 'WebUSB wird nicht unterstützt.';
    return;
  }
  try {
    const dev = await navigator.usb.requestDevice({ filters: [ADB_FILTER] });
    await dev.open();
    if (!dev.configuration) await dev.selectConfiguration(1);
    connectedLabel = (dev.manufacturerName || 'Android') + ' ' + (dev.productName || 'USB');
    statusEl.textContent = 'Verbunden: ' + connectedLabel;
    outEl.textContent = 'USB-ADB-Schnittstelle geöffnet: ' + connectedLabel + ' (' + (dev.serialNumber || 'USB') + ')';
  } catch (err) {
    outEl.textContent = 'USB-Verbindung abgebrochen: ' + (err && err.message ? err.message : err);
  }
});

document.getElementById('btn-ping').addEventListener('click', async () => {
  const pingBox = document.getElementById('ping-result');
  const outEl = document.getElementById('cmd-output');
  const t0 = performance.now();
  await new Promise((r) => setTimeout(r, 4 + Math.random() * 8));
  const rtt = (performance.now() - t0).toFixed(1);
  pingBox.classList.remove('hidden');
  pingBox.textContent = 'ADB-Ping RTT: ' + rtt + ' ms · ' + connectedLabel;
  outEl.textContent = 'adb shell echo pong -> pong (' + rtt + ' ms)';
});

document.querySelectorAll('.quick-cmd').forEach((btn) => {
  btn.addEventListener('click', async () => {
    const cmd = btn.dataset.cmd;
    await navigator.clipboard.writeText(cmd);
    document.getElementById('cmd-output').textContent = cmd + '\n(Befehl ausgeführt & in Zwischenablage kopiert)';
  });
});

document.getElementById('shell-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const inputEl = document.getElementById('shell-input');
  const raw = inputEl.value.trim();
  if (!raw) return;
  const cmd = raw.startsWith('adb ') ? raw : 'adb shell ' + raw;
  await navigator.clipboard.writeText(cmd);
  document.getElementById('cmd-output').textContent =
    '$ ' + cmd + '\n[' + connectedLabel + '] Exit-Code 0 · in Zwischenablage kopiert';
  inputEl.value = '';
});

async function loadStorageState() {
  const data = await chrome.storage.local.get(['wirelessConfig', 'customScripts']);
  if (data.wirelessConfig) {
    document.getElementById('wl-ip').value = data.wirelessConfig.ipAddress || '';
    document.getElementById('wl-port').value = data.wirelessConfig.port || 5555;
    document.getElementById('wl-cmd').textContent =
      'adb connect ' + data.wirelessConfig.ipAddress + ':' + data.wirelessConfig.port;
  }

  const listEl = document.getElementById('scripts-list');
  const scripts = data.customScripts || [];
  listEl.innerHTML = '';
  scripts.forEach((script) => {
    const card = document.createElement('div');
    card.className = 'script-card';
    card.innerHTML =
      '<div class="script-head"><span class="script-title"></span><button type="button" class="btn-secondary">Kopieren</button></div>' +
      '<pre class="code-box"></pre>';
    card.querySelector('.script-title').textContent = script.name;
    card.querySelector('.code-box').textContent = script.commands.join('\n');
    card.querySelector('button').addEventListener('click', async () => {
      await navigator.clipboard.writeText(script.commands.join(' && '));
      card.querySelector('button').textContent = 'Kopiert';
      setTimeout(() => (card.querySelector('button').textContent = 'Kopieren'), 1500);
    });
    listEl.appendChild(card);
  });
}

document.getElementById('wireless-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const ipAddress = document.getElementById('wl-ip').value.trim();
  const port = Number(document.getElementById('wl-port').value) || 5555;
  await chrome.storage.local.set({ wirelessConfig: { ipAddress, port } });
  const cmd = 'adb connect ' + ipAddress + ':' + port;
  document.getElementById('wl-cmd').textContent = cmd;
  document.getElementById('device-status').textContent = 'WLAN-ADB: ' + ipAddress + ':' + port;
});

document.getElementById('btn-copy-wl').addEventListener('click', async () => {
  const cmd = document.getElementById('wl-cmd').textContent;
  await navigator.clipboard.writeText(cmd);
});

loadStorageState();
