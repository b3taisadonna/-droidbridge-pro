# DroidBridge Pro — Chrome Extension (Manifest V3)

Version: `2.4.0`

## In Google Chrome / Edge installieren
1. Entpacke dieses `.zip`-Archiv in einen lokalen Ordner.
2. Öffne in Chrome die Adresse `chrome://extensions`.
3. Aktiviere oben rechts den **Entwicklermodus**.
4. Klicke auf **Entpackte Erweiterung laden** und wähle den entpackten Ordner aus.

## Enthaltene Funktionen
- Direkte **WebUSB-ADB-Verbindung** aus dem Browser-Popup
- **ADB-Ping** mit Round-Trip-Time-Messung
- **WLAN-ADB-Konfigurator** (vorausgefüllt mit `192.168.178.42:5555`)
- **Benutzerdefinierte ADB-Skripte** (4 Sequenzen synchronisiert)
- **Hintergrund-Wartungserinnerung** via `chrome.alarms` (alle 24 Std.)
